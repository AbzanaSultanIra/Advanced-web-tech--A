// pages/dashboard/bank-info.tsx
import React from 'react';

const BankInfoPage: React.FC = () => {
  return <div>Bank Info Page Content</div>;
};

export default BankInfoPage;
