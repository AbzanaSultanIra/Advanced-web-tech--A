// components/InvoicesList.js
import { useState, useEffect } from 'react';

const InvoicesList = () => {
  const [invoices, setInvoices] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch(''); // Replace with your API endpoint
        const data = await response.json();
        setInvoices(data);
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };

    fetchData();
  }, []);

  return (
    <div>
      <h2>Invoices List</h2>
      <table>
        <thead>
          <tr>
            <th>User ID</th>
            <th>Reference Num</th>
            <th>Company Name</th>
            <th>Purchase Date</th>
            <th>Due Date</th>
            <th>Total Amount</th>
            <th>Paid Amount</th>
            <th>Pending Amount</th>
          </tr>
        </thead>
        <tbody>
          {invoices.map((invoice) => (
            <tr key={invoice.id}>
              <td>{invoice.userId}</td>
              <td>{invoice.referenceNum}</td>
              <td>{invoice.companyName}</td>
              <td>{invoice.purchaseDate}</td>
              <td>{invoice.dueDate}</td>
              <td>{invoice.totalAmount}</td>
              <td>{invoice.paidAmount}</td>
              <td>{invoice.pendingAmount}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default InvoicesList;
