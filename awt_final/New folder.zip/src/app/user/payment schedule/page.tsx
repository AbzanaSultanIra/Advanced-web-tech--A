// pages/dashboard/payment-schedule.tsx
import React from 'react';

const PaymentSchedulePage: React.FC = () => {
  return <div>Payment Schedule Page Content</div>;
};

export default PaymentSchedulePage;
